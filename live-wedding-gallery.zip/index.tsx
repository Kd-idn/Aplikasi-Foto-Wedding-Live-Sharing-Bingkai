import React, { useState, useEffect, useRef, ChangeEvent, useCallback } from 'react';
import ReactDOM from 'react-dom/client';

interface GalleryPhoto {
  id: number; // Using timestamp as a unique ID
  dataUrl: string;
}

const App: React.FC = () => {
  const [frameImage, setFrameImage] = useState<HTMLImageElement | null>(null);
  const [framePreviewUrl, setFramePreviewUrl] = useState<string | null>(null);
  const [uploadedImageFile, setUploadedImageFile] = useState<File | null>(null);
  const [combinedImageUrl, setCombinedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [frameUploadSuccess, setFrameUploadSuccess] = useState<boolean>(false);
  const [galleryPhotos, setGalleryPhotos] = useState<GalleryPhoto[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const frameInputRef = useRef<HTMLInputElement>(null);

  // Load gallery photos from localStorage on initial mount
  useEffect(() => {
    try {
      const savedPhotos = localStorage.getItem('weddingGalleryPhotos');
      if (savedPhotos) {
        setGalleryPhotos(JSON.parse(savedPhotos));
      }
    } catch (e) {
      console.error("Failed to load gallery from localStorage:", e);
      setError("Error loading saved photos. Your browser storage might be full or corrupted.");
    }
  }, []);

  // Save gallery photos to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem('weddingGalleryPhotos', JSON.stringify(galleryPhotos));
    } catch (e) {
      console.error("Failed to save gallery to localStorage:", e);
      setError("Error saving photos. Your browser storage might be full.");
    }
  }, [galleryPhotos]);


  // Handle frame image upload by admin
  const handleFrameUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.type !== 'image/png') {
        setError('Please upload a transparent PNG file for the frame.');
        setFrameImage(null);
        setFramePreviewUrl(null);
        setFrameUploadSuccess(false);
        return;
      }
      setError(null);
      setFrameUploadSuccess(false); // Reset success message
      setCombinedImageUrl(null); // Clear any previously processed guest photos

      const img = new Image();
      const objectURL = URL.createObjectURL(file);
      img.src = objectURL;
      img.crossOrigin = 'anonymous';

      img.onload = () => {
        setFrameImage(img);
        setFramePreviewUrl(objectURL);
        setFrameUploadSuccess(true);
      };
      img.onerror = () => {
        setError("Error loading the frame image. Please ensure it's a valid image.");
        setFrameImage(null);
        setFramePreviewUrl(null);
        setFrameUploadSuccess(false);
        URL.revokeObjectURL(objectURL);
      };
    }
  };

  const processImage = async (imageFile: File, activeFrame: HTMLImageElement) => {
    setIsLoading(true);
    try {
      const img = new Image();
      img.src = URL.createObjectURL(imageFile);
      img.crossOrigin = 'anonymous';

      img.onload = () => {
        const canvas = document.createElement('canvas');
        // Set canvas dimensions to match the frame size
        canvas.width = activeFrame.naturalWidth;
        canvas.height = activeFrame.naturalHeight;
        const ctx = canvas.getContext('2d');

        if (ctx) {
          // Calculate scale to fit the image into the frame while maintaining aspect ratio (cover effect)
          const frameRatio = activeFrame.naturalWidth / activeFrame.naturalHeight;
          const imageRatio = img.naturalWidth / img.naturalHeight;

          let sx = 0, sy = 0, sWidth = img.naturalWidth, sHeight = img.naturalHeight; // Source image dimensions
          let dx = 0, dy = 0, dWidth = canvas.width, dHeight = canvas.height;     // Destination canvas dimensions

          if (imageRatio > frameRatio) { // Image is wider relative to the frame
            sHeight = img.naturalWidth / frameRatio; // Calculate source height needed to match frame ratio
            sy = (img.naturalHeight - sHeight) / 2; // Center vertically in source
          } else { // Image is taller relative to the frame, or same ratio
            sWidth = img.naturalHeight * frameRatio; // Calculate source width needed to match frame ratio
            sx = (img.naturalWidth - sWidth) / 2; // Center horizontally in source
          }

          // Draw the uploaded image first (cropped/scaled to fill the frame area)
          ctx.drawImage(img, sx, sy, sWidth, sHeight, dx, dy, dWidth, dHeight);

          // Draw the frame on top of the image
          ctx.drawImage(activeFrame, 0, 0, canvas.width, canvas.height);

          const newCombinedImageUrl = canvas.toDataURL('image/png');
          setCombinedImageUrl(newCombinedImageUrl);

          // Add to gallery
          setGalleryPhotos(prevPhotos => [{ id: Date.now(), dataUrl: newCombinedImageUrl }, ...prevPhotos]);

        } else {
          setError("Failed to get 2D context for canvas. Your browser might not support it.");
        }
        URL.revokeObjectURL(img.src); // Clean up the object URL to free memory
      };

      img.onerror = () => {
        setError("Error loading the uploaded photo. Please try a different image.");
        URL.revokeObjectURL(img.src);
      };
    } catch (e: any) {
      setError(`An unexpected error occurred during photo processing: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Modified handleDownload to accept URL and filename
  const handleDownload = useCallback((dataUrl: string, filename: string = 'wedding_photo.png') => {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, []);

  // Fix: Define handleGuestImageUpload
  const handleGuestImageUpload = useCallback((event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!frameImage) {
        setError("Please wait for the admin to upload a frame or upload one yourself.");
        return;
      }
      setError(null);
      setUploadedImageFile(file);
      processImage(file, frameImage);
    }
  }, [frameImage, processImage]);

  return (
    <div role="main" aria-labelledby="app-title">
      <h1 id="app-title">📸 Wedding Live Gallery</h1>

      <div className="admin-section" aria-labelledby="admin-title">
        <h3 id="admin-title">⚙️ Admin Dashboard</h3>
        <p>Upload a transparent PNG file for the wedding frame here.</p>
        <input
          type="file"
          accept="image/png"
          onChange={handleFrameUpload}
          ref={frameInputRef}
          aria-label="Upload wedding frame"
          id="frame-upload-input"
        />
        <label htmlFor="frame-upload-input" className="file-upload-label" tabIndex={0} role="button">
          Upload Bingkai (PNG)
        </label>
        {frameUploadSuccess && <p className="success-message" aria-live="polite">✅ Bingkai berhasil dipasang!</p>}
        {framePreviewUrl && (
          <div style={{ marginTop: '15px' }}>
            <p>Preview Bingkai:</p>
            <img src={framePreviewUrl} alt="Frame Preview" className="frame-preview" />
          </div>
        )}
        <p className="admin-info">Tips: Use a frame with the same aspect ratio as your camera photos (e.g., 3:2 or 4:3).</p>
      </div>

      <h2 aria-describedby="app-title">Upload a photo to frame your precious moments!</h2>

      {error && <p style={{ color: 'red', marginTop: '15px' }} role="alert">Error: {error}</p>}

      {!frameImage ? (
        <div className="warning-message" role="alert">
          ⚠️ Admin has not uploaded a frame yet. Please contact the photographer or upload one via the Admin Dashboard.
        </div>
      ) : (
        <>
          <input
            type="file"
            accept="image/png, image/jpeg"
            onChange={handleGuestImageUpload}
            ref={fileInputRef}
            aria-label="Upload a new photo"
            id="file-upload-input"
          />
          <label htmlFor="file-upload-input" className="file-upload-label" tabIndex={0} role="button">
            Upload Foto Baru
          </label>

          {isLoading && <p className="loading" aria-live="polite">Processing your photo...</p>}

          {combinedImageUrl && (
            <div style={{ marginTop: '30px' }}>
              <img
                src={combinedImageUrl}
                alt="Combined with frame"
                className="image-preview"
                aria-live="polite"
              />
              <button onClick={() => handleDownload(combinedImageUrl, 'wedding_photo.png')} className="download-button" aria-label="Download framed photo">
                Download Foto
              </button>
            </div>
          )}
        </>
      )}

      {/* Gallery Grid Section */}
      <div className="gallery-section">
        <h3>Wedding Photo Gallery</h3>
        {galleryPhotos.length === 0 ? (
          <p className="gallery-empty-message">No photos in the gallery yet. Start uploading!</p>
        ) : (
          <div className="gallery-grid">
            {galleryPhotos.map((photo) => (
              <div key={photo.id} className="gallery-item" aria-label={`Framed photo from ${new Date(photo.id).toLocaleDateString()}`}>
                <img src={photo.dataUrl} alt={`Gallery photo ${photo.id}`} className="gallery-image" />
                <button
                  onClick={() => handleDownload(photo.dataUrl, `wedding_photo_${photo.id}.png`)}
                  className="download-button gallery-download-button"
                  aria-label={`Download gallery photo ${photo.id}`}
                >
                  Download
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <p style={{ marginTop: '50px', fontSize: '0.8em', color: '#888' }}>---</p>
      <p style={{ fontSize: '0.8em', color: '#888' }}>Web Wedding Live Frame App - Built with Google AI Studio</p>
    </div>
  );
};

const rootElement = document.getElementById('root');
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}